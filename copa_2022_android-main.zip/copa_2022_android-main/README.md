# App Android Copa 2022

An android app made for the challenge of the DIO. In this app, you can choose if you want to receive a message notification just before the match.

In this was used:

* Retrofit
* Coroutines
* Flow
* Hilt
* Work Manager
* Jetpack Compose


<img src="./image/tela.jpg">
